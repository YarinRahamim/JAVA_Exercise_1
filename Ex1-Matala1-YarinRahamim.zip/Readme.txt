Matala1 -Prime GCD Code- Ex1 

שם: ירין רחמים
ת.ז: 205833668
  
הסבר הקוד עברית-  

1.הגדרת Scanner  הקולטת מידע מהמשתמש. 
2. מבקש מהמשתמש להכניס 2 מספרים ((a,b לפונקציית int  בשם GCD.
3. בדיקת המספר המקסימלי על ידי Math.max.
4. בדיקת המספר המינימלי על ידי Math min.
5. הגדרת משתנה int בשם tmp שווה ל-1. 
6. לולאת for עבור שבה נגדיר נבצע השמה ל-i באמצעות 2(i יתחיל מהספרה 2), נגדיר תנאי ש-i יהיה לפחות המספר המינימלי((i <= min, כשתנאים אלו מתקיימים להוסיף ל-i אחד  (i++). 
7. בלולאת for נוסיף שתי לולאות נוספות מסוג if.
8. הלולאה הראשונה תבוצע כאשר המספרים, המקסימלי והמינימלי, התחלקו ללא שארית ב-i.
9. הלולאה השנייה, במידה והלולאה הקודמת מתקיימת, תבדוק האם i(מקדם החלוקה) הוא מספר ראשוני. 
10. *בדיקה האם המספר ראשוני* (Prime). 
11. *הגדרת פונקציית  .Boolean prime ומשתנה מסוג int שנקרא n.
12. *הגדרת משתנה מסוג int  בשם count והשמת 0 (count <-- 0).
13. *יצירת לולאת for שבה נגדיר משתנה מסוג int  בשם i. 
14. *נבצע השמה ל i- באמצעות הספרה 2(i <-- 2), המספר הראשוני הקטן ביותר. 
15. *תנאי- i צריך להיות לפחות n (I <= n).
16. *במידה ותנאים אלו מתקיימים i יגדל ב-1 (i++).
17. *בתוך לולאת for ניצור עוד לולאה, if- שבה נבדוק האם n מתחלק ללא שארית ב-i.
18. *במידה ותנאים אלו מתקיימים count יגדל ב- 1 (count ++).
19. *ניצור לולאת if  ונגדיר אותה, כך שאם count  שווה ל-1 שיחזיר שהמספר אכן ראשוני. 
20. *אחרת שיחזיר שקר, המספר אינו ראשוני. 
21. אם i הוא ראשוני תגדיר את i(החדש) ב-tmp. 
22. תדפיס את tmp. 

הסבר קוד אנגלית- 

/* Put 2 numbers (a,b)
 * Check for max and min with Math.max && Math.min
 *Variable int with "tmp" name, tmp = 1
 * Loop "for" i <-- 2, i <= min , i++
 * In loop "for" add two "if" (if1 , if 2) loop
 * "if1" run only if the numbers(a,b) % i == 0 
 * "if2" if the "if1" true check if "i" is a prime 
 * ***Is-Prime Number***
 * Boolean prime function
 * Variable int "n" && int "count" <-- 0
 * Loop "for" int i <-- 2, i <= n , i++
 * In loop "for" add loop "if"
 * In "if" loop n%i == 0
 * If the loops is true count ++
 * Add "if" loop, check if count == 1 return true (is a prime number)
 * Else (if count not equal 1) return false (is not a prime number)  
 * ***End Is-Prime***
 * if "i" is a prime number, tmp <-- new "i" 
 * return tmp
 */
